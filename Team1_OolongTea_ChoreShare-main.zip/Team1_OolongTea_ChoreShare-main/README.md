# ChoreShare

A social media site for sharing chores and productivity tasks you have completed throughout the day!

## Technologies Used
- HTML <br>
- CSS <br>
- JavaScript <br>
- Python
  
---

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/witusyd-LaunchPad-2024/Team1_OolongTea_ChoreShare.git

2. Navigate to the project folder:

   ```bash
   cd repository

3. Open index.html 
